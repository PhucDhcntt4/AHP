from fpdf import FPDF
from datetime import datetime
import base64
import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import io
import tempfile
import os
import psycopg2

def get_conn():
    return psycopg2.connect(
        dbname="AHP",
        user="postgres",
        password="123",
        host="localhost",
        port="5433"
    )
# Khởi tạo trạng thái
if "tinh_tieu_chi" not in st.session_state:
    st.session_state["tinh_tieu_chi"] = False
if "tinh_phuong_an" not in st.session_state:
    st.session_state["tinh_phuong_an"] = False

# Cấu hình trang
st.set_page_config(
    page_title="AHP - Hệ hỗ trợ ra quyết định",
    page_icon="icon.png"
)

page = st.sidebar.selectbox(
    "Chọn chức năng",
    ("Phân tích AHP", "Lịch sử các phiên")
)

if page == "Phân tích AHP":
    st.title("AHP (Nhóm 7) - Hệ hỗ trợ ra quyết định khen thưởng")

    # Nhập danh sách tiêu chí
    st.subheader("Nhập các tiêu chí đánh giá (cách nhau bằng dấu phẩy)")
    input_tieu_chi = st.text_area(
        "Ví dụ: Kết quả làm việc, Chất lượng công việc, Sáng tạo,...",
        value="Kết quả làm việc, Chất lượng công việc, Sáng tạo & Cải tiến, Tinh thần làm việc nhóm, Trách nhiệm & Kỷ luật"
    )
    tieu_chi = [t.strip() for t in input_tieu_chi.split(",") if t.strip()]
    n = len(tieu_chi)

    # Kiểm tra số lượng tiêu chí
    if n < 2:
        st.warning("⚠️ Cần nhập ít nhất 2 tiêu chí.")
        st.stop()
    if n > 10:
        st.warning("⚠️ Số lượng tiêu chí tối đa là 10. Vui lòng nhập lại.")
        st.stop()

    # Hàm tạo ma trận mặc định
    def default_matrix():
        return pd.DataFrame(
            [["1" if i == j else "1" for j in range(n)] for i in range(n)],
            columns=tieu_chi,
            index=tieu_chi
        )

    # Hàm chuyển giá trị từ chuỗi sang số
    def chuyen_doi_so(val):
        try:
            val = eval(str(val))
            if isinstance(val, (int, float)):
                return float(val)
            return np.nan
        except:
            return np.nan

    # Tải lên file Excel
    st.subheader("Tải ma trận so sánh từ Excel (tùy chọn)")
    upload_file = st.file_uploader("Tải lên ma trận so sánh (Excel)", type=['xlsx'])

    # Khởi tạo ma trận đầu vào
    matrix_data = None
    if upload_file is not None:
        try:
            df_excel = pd.read_excel(upload_file, index_col=0)
            if df_excel.shape == (n, n):
                matrix_data = df_excel.astype(str)
                st.success("Đã tải ma trận từ file Excel thành công!")
            else:
                st.warning(f"⚠️ Kích thước ma trận cần là {n}x{n}, nhưng bạn đã upload ma trận {df_excel.shape}")
        except Exception as e:
            st.error(f"❌ Lỗi đọc file: {e}")

    # Dùng ma trận mặc định nếu không có file
    if matrix_data is None:
        matrix_data = default_matrix()

    # Nhập dữ liệu từ người dùng
    st.subheader("Nhập hoặc chỉnh sửa ma trận so sánh cặp")
    input_df = st.data_editor(
        matrix_data,
        num_rows="fixed",
        key="pairwise_input",
        use_container_width=True,
        height=250
    )

    # Chuyển giá trị về float
    input_df = input_df.applymap(chuyen_doi_so)

    # Kiểm tra và thông báo nếu dữ liệu không hợp lệ
    if (input_df > 9).any().any():
        st.warning("Có giá trị lớn hơn 9. Vui lòng nhập trong khoảng từ 1 đến 9.")
    elif (input_df <= 0.1).any().any():
        st.warning("Có giá trị nhỏ hơn 0.1. Vui lòng nhập trong khoảng từ 0.111 đến 9.")

    # Đảm bảo đường chéo là 1
    for i in range(n):
        if input_df.iat[i, i] != 1.0:
            st.info(f"Tự động đặt lại giá trị tại dòng {i+1}, cột {i+1} = 1 (đường chéo)")
            input_df.iat[i, i] = 1.0
            st.session_state["pairwise_input"].iat[i, i] = "1"

    # Hiển thị lại bảng đã hiệu chỉnh
    hienthi_df = input_df.astype(str)
    for i in range(n):
        hienthi_df.iat[i, i] = "1"
    st.subheader("Ma trận sau khi hiệu chỉnh")
    st.dataframe(hienthi_df, use_container_width=True)

    # Tính toán
    if st.button("Tính toán"):
        st.session_state["tinh_tieu_chi"] = True
        st.session_state["tinh_phuong_an"] = False

    if st.session_state["tinh_tieu_chi"]:
        try:
            st.subheader("Ma trận so sánh cặp")
            st.dataframe(input_df, use_container_width=True)

            pairwise_matrix = input_df.to_numpy(dtype=float)

            if np.any(pairwise_matrix > 9):
                st.error("Giá trị trong ma trận không được vượt quá 9. Vui lòng kiểm tra lại.")
                st.stop()

            # 1. Tổng mỗi cột
            col_sums = pairwise_matrix.sum(axis=0)
            st.subheader("Tổng mỗi cột")
            st.dataframe(pd.DataFrame([col_sums], columns=tieu_chi), use_container_width=True)
            st.bar_chart(pd.DataFrame(col_sums, index=tieu_chi, columns=["Tổng"]))

            # 2. Ma trận chuẩn hóa
            normalized_matrix = pairwise_matrix / col_sums
            st.subheader("Ma trận chuẩn hóa")
            norm_df = pd.DataFrame(normalized_matrix, columns=tieu_chi, index=tieu_chi)
            st.dataframe(norm_df, use_container_width=True)

            # 3. Trọng số tiêu chí
            weights = normalized_matrix.mean(axis=1)
            st.subheader("Trọng số tiêu chí")
            result_df = pd.DataFrame({"Tiêu chí": tieu_chi, "Trọng số": weights})
            st.dataframe(result_df, use_container_width=True)
            st.bar_chart(result_df.set_index("Tiêu chí"))

            # 4. Kiểm tra độ nhất quán
            weighted_sum = pairwise_matrix.dot(weights)
            lambda_max = (weighted_sum / weights).mean()
            CI = (lambda_max - n) / (n - 1)
            RI_dict = {1: 0.00, 2: 0.00, 3: 0.58, 4: 0.90, 5: 1.12,
                       6: 1.24, 7: 1.32, 8: 1.41, 9: 1.45, 10: 1.49}
            RI = RI_dict[n]
            CR = CI / RI if RI != 0 else 0

            st.subheader("Kiểm tra độ nhất quán")
            st.write(f"λ max: {lambda_max:.4f}")
            st.write(f"CI (Consistency Index): {CI:.4f}")
            st.write(f"CR (Consistency Ratio): {CR:.4f}")

            if CR < 0.1:
                st.success("Ma trận có độ nhất quán (CR < 0.1). Có thể tiếp tục tính các phương án.")
                st.session_state["tieu_chi_weights"] = weights
                st.session_state["tieu_chi_consistent"] = True
            else:
                st.error("Ma trận KHÔNG hợp lý (CR ≥ 0.1). Vui lòng nhập lại.")
                st.session_state["tieu_chi_consistent"] = False
                if st.button("Nhập lại ma trận"):
                    st.experimental_rerun()

        except Exception as e:
            st.error(f"Lỗi xử lý ma trận: {e}")

    # Tiếp tục xử lý các phương án nếu ma trận tiêu chí hợp lý
    if st.session_state.get("tieu_chi_consistent", True):
        st.subheader("Nhập danh sách phương án")
        options = st.text_input("Nhập tên các phương án, cách nhau bởi dấu phẩy", value="Nhân viên A, Nhân viên B, Nhân viên C, Nhân viên D")
        option_names = [opt.strip() for opt in options.split(",")]
        m = len(option_names)

        option_weights_dict = {}

    if "tieu_chi_weights" in st.session_state:
        for idx, crit in enumerate(tieu_chi):
            st.markdown(f"### Ma trận so sánh cặp giữa các phương án theo tiêu chí: **{crit}**")

            def default_option_matrix():
                return pd.DataFrame(
                    [["1" if i == j else "1" for j in range(m)] for i in range(m)],
                    columns=option_names,
                    index=option_names
                )
            option_df = st.data_editor(
                default_option_matrix(),
                num_rows="fixed",
                key=f"opt_input_{crit}",
                use_container_width=True,
                height=210
            )

            option_df = option_df.applymap(chuyen_doi_so)

            if (option_df > 9).any().any():
                st.warning("Có giá trị lớn hơn 9. Vui lòng nhập trong khoảng từ 1 đến 9.")
            elif (option_df < 0.1).any().any():
                st.warning("Có giá trị nhỏ hơn 0.1. Vui lòng nhập trong khoảng từ 0.111 đến 9.")

            try:
                matrix = option_df.to_numpy(dtype=float)
                col_sum = matrix.sum(axis=0)
                norm_matrix = matrix / col_sum
                weights_opt = norm_matrix.mean(axis=1)
                option_weights_dict[crit] = weights_opt

                chart_df = pd.DataFrame({"Phương án": option_names, "Trọng số": weights_opt})
                st.dataframe(chart_df, use_container_width=True)
                st.bar_chart(chart_df.set_index("Phương án"))

                weighted_sum = matrix @ weights_opt
                lambda_max = (weighted_sum / weights_opt).mean()
                CI = (lambda_max - m) / (m - 1)
                RI_dict = {1: 0.00, 2: 0.00, 3: 0.58, 4: 0.90, 5: 1.12, 6: 1.24, 7: 1.32, 8: 1.41, 9: 1.45, 10: 1.49}
                RI = RI_dict.get(m, 1.49)
                CR = CI / RI if RI != 0 else 0

                st.markdown(f"**Đánh giá độ nhất quán - tiêu chí _{crit}_**")
                st.write(f"λ max: {lambda_max:.4f}")
                st.write(f"CI: {CI:.4f}")
                st.write(f"CR: {CR:.4f}")
                if CR < 0.1:
                    st.success("Ma trận nhất quán (CR < 0.1)")
                else:
                    st.warning("Ma trận KHÔNG nhất quán (CR ≥ 0.1)")

            except Exception as e:
                st.error(f"Lỗi khi xử lý ma trận phương án cho tiêu chí {crit}: {e}")

    if st.button("Tính trọng số tổng hợp các phương án"):
        st.session_state["tinh_phuong_an"] = True

    if st.session_state["tinh_phuong_an"]:
        try:
            final_weights = np.zeros(m)
            for i, crit in enumerate(tieu_chi):
                if crit in option_weights_dict:
                    final_weights += st.session_state["tieu_chi_weights"][i] * option_weights_dict[crit]

            final_df = pd.DataFrame({
                "Phương án": option_names,
                "Trọng số tổng hợp": final_weights
            })

            final_df["Xếp hạng"] = final_df["Trọng số tổng hợp"].rank(ascending=False, method="min").astype(int)

            tong_ts = final_df["Trọng số tổng hợp"].sum()
            final_df["%"] = (final_df["Trọng số tổng hợp"] / tong_ts * 100).round(2).astype(str) + "%"

            ts_df = pd.DataFrame({
                "Tiêu chí": tieu_chi,
                "Trọng số tiêu chí": st.session_state["tieu_chi_weights"]
            })

            st.subheader("Trọng số các tiêu chí")
            st.dataframe(ts_df, use_container_width=True)

            st.subheader("Trọng số tổng hợp các phương án")
            best_option = final_df.sort_values("Xếp hạng").iloc[0]["Phương án"]
            st.success(f"Phương án được đề xuất xếp hạng cao nhất là: **{best_option}**")
            st.dataframe(final_df.sort_values("Xếp hạng"), use_container_width=True)
            st.bar_chart(final_df.set_index("Phương án")["Trọng số tổng hợp"])


            st.subheader("Biểu đồ tròn: Phân bổ trọng số phương án")
            colors = plt.cm.Set3(np.linspace(0, 1, m))
            fig, ax = plt.subplots(figsize=(6, 6))
            ax.pie(
                final_weights,
                labels=option_names,
                autopct="%1.1f%%",
                startangle=90,
                colors=colors
            )
            ax.axis("equal")
            st.pyplot(fig)

            # Tạo file Excel tạm thời
            with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
                with pd.ExcelWriter(tmp.name, engine='xlsxwriter') as writer:
                    # Sheet 1: Ma trận so sánh cặp
                    input_df.to_excel(writer, sheet_name="Ma trận so sánh cặp")
                    # Sheet 2: Ma trận chuẩn hóa
                    norm_df.to_excel(writer, sheet_name="Ma trận chuẩn hóa")
                    # Sheet 3: Trọng số tiêu chí
                    result_df.to_excel(writer, sheet_name="Trọng số tiêu chí", index=False)
                    # Sheet 4: Trọng số phương án từng tiêu chí
                    for crit in option_weights_dict:
                        pd.DataFrame({
                            "Phương án": option_names,
                            f"Trọng số ({crit})": option_weights_dict[crit]
                        }).to_excel(writer, sheet_name=f"TS {crit}", index=False)
                    # Sheet 5: Trọng số tổng hợp các phương án
                    final_df.to_excel(writer, sheet_name="Kết quả AHP", index=False)
                tmp.seek(0)
                excel_data = tmp.read()

            st.download_button(
                label="⬇ Tải tất cả kết quả (Excel)",
                data=excel_data,
                file_name="ket_qua_ahp.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
            def add_table(pdf, df, col_widths=None, align="C"):
                pdf.set_font("DejaVu", size=9)
                page_width = pdf.w - 2 * pdf.l_margin
                if col_widths is None:
                    # Ước lượng chiều rộng từng cột
                    col_widths = []
                    for col in df.columns:
                        max_len = max([len(str(val)) for val in df[col]] + [len(str(col))])
                        col_widths.append(max(18, min(3.2 * max_len, 45)))
                    total_width = sum(col_widths)
                    # Nếu tổng lớn hơn trang, co lại theo tỉ lệ
                    if total_width > page_width:
                        ratio = page_width / total_width
                        col_widths = [w * ratio for w in col_widths]
                # Header
                for i, col in enumerate(df.columns):
                    pdf.cell(col_widths[i], 8, str(col), border=1, align=align)
                pdf.ln()
                # Rows
                for idx, row in df.iterrows():
                    for i, col in enumerate(df.columns):
                        val = row[col]
                        if isinstance(val, float):
                            val = f"{val:.3f}"
                        pdf.cell(col_widths[i], 8, str(val), border=1, align=align)
                    pdf.ln()
                pdf.ln(2)
            # Tạo file PDF báo cáo
            class PDF(FPDF):
                def header(self):
                    self.set_font("DejaVu", size=16)
                    self.cell(0, 10, "Báo cáo kết quả AHP", ln=True, align="C")
                    self.ln(2)

            font_path = "DejaVuSans.ttf"
            if not os.path.exists(font_path):
                st.error("Thiếu file font DejaVuSans.ttf để xuất PDF tiếng Việt. Vui lòng tải font này về cùng thư mục!")
            else:
                pdf = PDF()
                pdf.add_font("DejaVu", "", font_path, uni=True)
                pdf.add_page()
                pdf.set_font("DejaVu", size=10)
                pdf.cell(0, 10, f"Ngày tạo: {datetime.now().strftime('%d/%m/%Y %H:%M')}", ln=True)
                pdf.ln(5)

                # 1. Ma trận so sánh cặp
                pdf.cell(0, 10, "Ma trận so sánh cặp:", ln=True)
                add_table(pdf, input_df.round(3).rename_axis("Tiêu chí").reset_index())

                # 3. Trọng số các tiêu chí
                pdf.cell(0, 10, "Trọng số các tiêu chí:", ln=True)
                add_table(pdf, ts_df)

                fig, ax = plt.subplots(figsize=(5, 3))
                ax.bar(ts_df["Tiêu chí"], ts_df["Trọng số tiêu chí"], color=plt.cm.Set3.colors)
                ax.set_ylabel("Trọng số")
                ax.set_title("Biểu đồ trọng số các tiêu chí")
                fig.tight_layout()

                with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp_ts_file:
                    fig.savefig(tmp_ts_file.name, format="png")
                    plt.close(fig)
                    pdf.image(tmp_ts_file.name, x=10, w=pdf.w - 20)
                    pdf.ln(5)

                # 4. Trọng số phương án từng tiêu chí
                for crit in option_weights_dict:
                    pdf.cell(0, 10, f"Trọng số phương án theo tiêu chí: {crit}", ln=True)
                    crit_df = pd.DataFrame({
                        "Phương án": option_names,
                        f"Trọng số ({crit})": option_weights_dict[crit]
                    })
                    add_table(pdf, crit_df)

                # 5. Trọng số tổng hợp các phương án
                pdf.cell(0, 10, "Trọng số tổng hợp các phương án:", ln=True)
                add_table(pdf, final_df.sort_values("Xếp hạng"))

                # 6. Phương án tốt nhất
                pdf.cell(0, 10, f"Phương án được đề xuất: {best_option}", ln=True)
                pdf.ln(5)

                # 7. Biểu đồ
                bar_fig, bar_ax = plt.subplots(figsize=(5, 3))
                bar_ax.bar(final_df["Phương án"], final_df["Trọng số tổng hợp"], color=plt.cm.Set3.colors)
                bar_ax.set_ylabel("Trọng số tổng hợp")
                bar_ax.set_title("Trọng số tổng hợp các phương án")
                bar_fig.tight_layout()

                with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp_bar_file:
                    bar_fig.savefig(tmp_bar_file.name, format="png")
                    plt.close(bar_fig)
                    pdf.image(tmp_bar_file.name, x=10, w=pdf.w - 20)
                    pdf.ln(5)

                # Pie chart
                pie_fig, pie_ax = plt.subplots(figsize=(4, 4))
                pie_ax.pie(
                    final_weights,
                    labels=option_names,
                    autopct="%1.1f%%",
                    startangle=90,
                    colors=plt.cm.Set3(np.linspace(0, 1, m))
                )
                pie_ax.axis("equal")
                pie_fig.tight_layout()

                with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp_pie_file:
                    pie_fig.savefig(tmp_pie_file.name, format="png")
                    plt.close(pie_fig)
                    pdf.image(tmp_pie_file.name, x=30, w=pdf.w - 60)
                    pdf.ln(5)

                # Lưu PDF vào bộ nhớ
                pdf_output = pdf.output(dest="S").encode("latin1")
                st.download_button(
                    label="⬇ Tải báo cáo PDF",
                    data=pdf_output,
                    file_name="bao_cao_ahp.pdf",
                    mime="application/pdf"
                )
        except Exception as e:
            st.error(f"Lỗi khi tính trọng số tổng hợp: {e}")

    # ...sau khi tính toán xong...

    def save_ahp_to_db(tieu_chi, option_names, input_df, ts_df, option_weights_dict, final_df, description=""):
        conn = get_conn()
        cur = conn.cursor()

        # 1. Tạo mới
        cur.execute("INSERT INTO ahp_session (description) VALUES (%s) RETURNING id", (description,))
        session_id = cur.fetchone()[0]

        # 2. Lưu tiêu chí
        crit_ids = []
        for crit in tieu_chi:
            cur.execute("INSERT INTO criteria (name, ahp_session_id) VALUES (%s, %s) RETURNING id", (crit, session_id))
            crit_ids.append(cur.fetchone()[0])

        # 3. Lưu phương án
        opt_ids = []
        for opt in option_names:
            cur.execute("INSERT INTO options (name, ahp_session_id) VALUES (%s, %s) RETURNING id", (opt, session_id))
            opt_ids.append(cur.fetchone()[0])

        # 4. Lưu ma trận so sánh cặp tiêu chí
        for i, crit1 in enumerate(tieu_chi):
            for j, crit2 in enumerate(tieu_chi):
                value = input_df.iloc[i, j]
                cur.execute(
                    "INSERT INTO pairwise_criteria (criteria1_id, criteria2_id, value, ahp_session_id) VALUES (%s, %s, %s, %s)",
                    (crit_ids[i], crit_ids[j], float(value), session_id)
                )

        # 5. Lưu trọng số tiêu chí
        for i, crit in enumerate(tieu_chi):
            weight = ts_df.iloc[i]["Trọng số tiêu chí"]
            cur.execute(
                "INSERT INTO weights_criteria (criteria_id, weight, ahp_session_id) VALUES (%s, %s, %s)",
                (crit_ids[i], float(weight), session_id)
            )

        # 6. Lưu trọng số phương án từng tiêu chí
        for cidx, crit in enumerate(tieu_chi):
            weights = option_weights_dict[crit]
            for oidx, opt in enumerate(option_names):
                cur.execute(
                    "INSERT INTO weights_options (criteria_id, option_id, weight, ahp_session_id) VALUES (%s, %s, %s, %s)",
                    (crit_ids[cidx], opt_ids[oidx], float(weights[oidx]), session_id)
                )

        # 7. Lưu trọng số tổng hợp các phương án
        for i, row in final_df.iterrows():
            cur.execute(
                "INSERT INTO final_weights (option_id, weight, rank, ahp_session_id) VALUES (%s, %s, %s, %s)",
                (opt_ids[i], float(row["Trọng số tổng hợp"]), int(row["Xếp hạng"]), session_id)
            )


        conn.commit()
        cur.close()
        conn.close()
        
    if st.button("💾 Lưu kết quả vào cơ sở dữ liệu"):
        try:
            save_ahp_to_db(
                tieu_chi,
                option_names,
                input_df,
                ts_df,
                option_weights_dict,
                final_df,
                description="AHP khen thưởng"
            )
            st.success("Đã lưu kết quả vào cơ sở dữ liệu thành công!")
        except Exception as e:
            st.error(f"Lỗi khi lưu vào cơ sở dữ liệu: {e}")

if page == "Lịch sử các phiên":
    st.title("Lịch sử các phiên phân tích AHP")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT id, created_at, description FROM ahp_session ORDER BY created_at DESC")
    rows = cur.fetchall()
    cur.close()
    conn.close()

    if not rows:
        st.info("Chưa có phiên phân tích nào được lưu.")
    else:
        df = pd.DataFrame(rows, columns=["ID", "Thời gian", "Mô tả"])
        st.dataframe(df, use_container_width=True)

        selected_id = st.selectbox("Chọn phiên để xem chi tiết", df["ID"])
        if st.button("Xem chi tiết"):
            # Hiển thị phiên 
            conn = get_conn()
            cur = conn.cursor()
            # Lấy tiêu chí
            cur.execute("SELECT name FROM criteria WHERE ahp_session_id=%s", (selected_id,))
            tieu_chi = [r[0] for r in cur.fetchall()]
            # Lấy phương án
            cur.execute("SELECT name FROM options WHERE ahp_session_id=%s", (selected_id,))
            option_names = [r[0] for r in cur.fetchall()]
            # Lấy trọng số tiêu chí
            cur.execute("""
                SELECT c.name, w.weight FROM weights_criteria w
                JOIN criteria c ON w.criteria_id = c.id
                WHERE w.ahp_session_id=%s
            """, (selected_id,))
            ts_df = pd.DataFrame(cur.fetchall(), columns=["Tiêu chí", "Trọng số tiêu chí"])
            st.subheader("Trọng số các tiêu chí")
            st.dataframe(ts_df)
            # Lấy trọng số tổng hợp các phương án
            cur.execute("""
                SELECT o.name, f.weight, f.rank FROM final_weights f
                JOIN options o ON f.option_id = o.id
                WHERE f.ahp_session_id=%s
                ORDER BY f.rank
            """, (selected_id,))
            final_df = pd.DataFrame(cur.fetchall(), columns=["Phương án", "Trọng số tổng hợp", "Xếp hạng"])
            st.subheader("Trọng số tổng hợp các phương án")
            st.dataframe(final_df)
            cur.close()
            conn.close()
