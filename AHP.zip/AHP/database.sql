CREATE TABLE ahp_session (
    id SERIAL PRIMARY KEY,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    description VARCHAR(255)
);

CREATE TABLE criteria (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    ahp_session_id INT REFERENCES ahp_session(id)
);

CREATE TABLE options (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    ahp_session_id INT REFERENCES ahp_session(id)
);

CREATE TABLE pairwise_criteria (
    id SERIAL PRIMARY KEY,
    criteria1_id INT REFERENCES criteria(id),
    criteria2_id INT REFERENCES criteria(id),
    value FLOAT,
    ahp_session_id INT REFERENCES ahp_session(id)
);

CREATE TABLE weights_criteria (
    id SERIAL PRIMARY KEY,
    criteria_id INT REFERENCES criteria(id),
    weight FLOAT,
    ahp_session_id INT REFERENCES ahp_session(id)
);

CREATE TABLE weights_options (
    id SERIAL PRIMARY KEY,
    criteria_id INT REFERENCES criteria(id),
    option_id INT REFERENCES options(id),
    weight FLOAT,
    ahp_session_id INT REFERENCES ahp_session(id)
);

CREATE TABLE final_weights (
    id SERIAL PRIMARY KEY,
    option_id INT REFERENCES options(id),
    weight FLOAT,
    rank INT,
    ahp_session_id INT REFERENCES ahp_session(id)
);